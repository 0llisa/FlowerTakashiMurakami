let flowerAchievement;
let flowerTakashi;
let width;
let height;
let scoreValue;
let contactCard;

function playGame() {
  createCanvas(1280, 2000);
  frameRate(10);
  flowerTakashi = new flowerT();
  flowerTakashiLocation();
  flowerAchievementLocation();
  scoreValue = 0;
  scoreValue.innerText = "Score: ";
}

function flowerTakashi(x, y, s, r, g, b) {
  background(255, 255, 255);
  translate(580, 200);
  noStroke();
  for (let i = 0; i < 100; i++) {
    ellipse(x, y, 25 * s, 100 * s);
    rotate(PI / 5);
  }
  push();
  strokeWeight(3 * s);
  fill(255, 255, 255);
  ellipse(x, y, 200 * s);
  //1.0 leftEye
  push();
  noStroke();
  fill(r, g, b);
  ellipse(x + 37 * s, y - 50 * s, 15 * s, 26 * s);
  noStroke();
  fill(r, g, b);
  ellipse(x - 37 * s, y - 50 * s, 15 * s, 26 * s);
  pop();
  //black stroke appears
  push();
  //small sparkle #1
  push();
  noStroke();
  fill(r, g, b);
  push();
  ellipse(x - 37 * s, y - 56 * s, 9 * s, 14 * s);
  pop();
  push();
  ellipse(x + 37 * s, y - 56 * s, 9 * s, 14 * s);
  //more sparkles on eyes
  fill(r, g, b);
  ellipse(x - 37 * s, y - 45 * s, 7 * s, 11 * s);
  ellipse(x + 37 * s, y - 45 * s, 7 * s, 11 * s);
  pop();
  //1.3 mouth
  push();
  fill(r, g, b);
  stroke("pink");
  strokeWeight(3);
  arc(x, y - 15 * s, 160 * s, 13 * s, 0, TWO_PI);
  arc(x, y - 15 * s, 160 * s, 190 * s, 0, PI);
  pop();
}

function mouseClicked() {
  for (i = 0; i < 10; i++) {
    flowerTakashi(
      mouseX,
      mouseY,
      0.5,
      random(40, 60),
      random(0, 255),
      random(0, 255)
    );
  }
}

function drawflowerAchievement(x, y, d, r, g, b) {
  fill(255, 255, 0);
  ellipse(x, y, d, d);
  fill(r, g, b);
  ellipse(x - 50, y, d, d);
  ellipse(x + 50, y, d, d);
  ellipse(x - 25, y + 43, d, d);
  ellipse(x + 25, y + 43, d, d);
  ellipse(x - 25, y - 43, d, d);
  ellipse(x + 25, y - 43, d, d);
}

function mouseClicked() {
  for (i = 0; i < 10; i++) {
    flowerAchievement(
      mouseX,
      mouseY,
      random(40, 60),
      random(0, 255),
      random(0, 255),
      random(0, 255)
    );
  }

  if (mouseClicked() == flowerAchievement) {
    scoreValue++;
    score.innerText = "Score: " + scoreValue;
  }
}

function drawflowerAchievement() {
  flowerAchievement = {
    x: Mouth.round(Math.random() * 1280),
    y: Mouth.round(Math.random() * 2000),
  };
  ctx.upload(flowerAchievement.x, flowerAchievement.y, size, size);
}

function finishGame() {
  if (flowerGame.finishGame()) {
    if (
      flowerTakash.mouseClicked() >= (i > 10) &&
      flowerAchievement.mouseClicked() < (i = 2)
    ) {
      print("END GAME");
      background(0, 0, 0);
      noLoop();
      setup();
    }
  }
}

contactCard(){
function phonenumber() {
    error = 0;
  
    let phone = document.getElementById("phone").value;
    let validnumber = ["+", "-", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    //phone format checking
    for (let i = 0; i < phone.length; i++) {
      for (let v = 0; v < validnumber.length; v++) {
        if (phone[i] == validnumber[v]) {
          break;
        }
  
        else if (phone[i] !== validnumber[v] && v == validnumber.length - 1) {
          error = 1;
        }
      }
    }
  }
}

function winGame() {
  if (flowerGame.winGame()) {
    if (
      flowerTakash.mouseClicked()((i = 10)) &&
      flowerAchievement.mouseClicked() == (i = 2)
    ) {
      print("YOU WIN!");
      background(0, 0, 0);
      noLoop();
      setup();
      function contactCard()
    }
  }
}
