$(window).scroll(function () {
    var scroll = $(window).scrollTop();
    if (scroll > 400) {
        $('.header__wrapper').addClass('fixed');
        // $('.nav-link').addClass('fixed');
        // $('.nav-link::after').addClass('fixed');
    } else {

        $('.header__wrapper').removeClass('fixed');
        // $('.nav-link').removeClass('fixed');
        // $('.nav-link::after').removeClass('fixed');
    }
})
var rellax = new Rellax('.rellax');