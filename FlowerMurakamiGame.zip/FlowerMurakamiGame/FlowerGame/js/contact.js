let profiles = [];
let error = 0;
let correctemail = 0;
let turnJASON;
//saving the data when the pg is refreshed:
if (localStorage.elements !== undefined) {
  //creates JSON to an element/array
  profiles = JSON.parse(localStorage.elements);
}
let profile = {};


//Alert to warn about empty field
function sendData() {
  if (document.getElementById("name").value == "" || document.getElementById("phone").value == "" || document.getElementById("email").value == "" || document.getElementById("address").value == "") {
    alert("Please, fullfill empty fields")
  }
  else {
    checker()
  }
}

//Checks the format of mail and phone 
function checker() {
  correctemail = 0;
  let emaifield = document.getElementById("email").value;

  //email format checking
  for (let i = 0; i < emaifield.length; i++) {
    if (emaifield[i] !== "@") {
      correctemail = 0;
    }
    else {
      correctemail = 1;
      break;
    }
  }

  phonenumber();

  if (correctemail == 0) {
    alert("Not correct email")
  }
  else if (error) {
    alert("Not correct number")
  }
  else {
    infoAd();
    datacard();
    correctemail = 0;
    error = 0;
  }
}

//What exact to fill in field

function phonenumber() {
  error = 0;

  let phone = document.getElementById("phone").value;
  let validnumber = ["+", "-", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
  //phone format checking
  for (let i = 0; i < phone.length; i++) {
    for (let v = 0; v < validnumber.length; v++) {
      if (phone[i] == validnumber[v]) {
        break;
      }

      else if (phone[i] !== validnumber[v] && v == validnumber.length - 1) {
        error = 1;
      }
    }
  }
}


//adding elements to the array
function infoAd() {
  profile = {
    name: document.getElementById("name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    address: document.getElementById("address").value
  }

  //push elements to array

  profiles.push(profile);

  //turn array to JSON

  turnJASON = JSON.stringify(profiles);

  //Clears inputfields

  localStorage.setItem('elements', turnJASON);
  document.getElementById('name').value = '';
  document.getElementById('phone').value = '';
  document.getElementById('email').value = '';
  document.getElementById('address').value = '';
  console.log(profiles);
}



function removecard(i) {
  profiles.splice(i, 1);
  localStorage.setItem("elements", JSON.stringify(profiles));

  //turnJASON =JSON.stringify(profiles);
  datacard();
}

////Create cards
function datacard() {
  document.getElementById('namecard').innerHTML = "";

  for (let i = 0; i < profiles.length; i++) {

    let newcard = document.createElement("div");
    let paragraf = document.createElement("p");


    let deletebutton = document.createElement("button");

    deletebutton.setAttribute("onclick", "removeCard(" + i + ")");
    deletebutton.innerHTML = "Delete element";


    newcard.classList.add("card");
    paragraf.setAttribute("id", "name" + i);
    //make cards appear
    document.getElementById("namecard").appendChild(newcard);
    //paragraph where the data will be
    document.getElementsByClassName("card")[i].appendChild(paragraf);
    //button after the paragraph
    document.getElementsByClassName("card")[i].appendChild(deletebutton);
    //things that appear in the paragraph
    document.getElementById("name" + i).innerHTML = "Name: " + profiles[i].name + "<br> Phone: " + profiles[i].phone + "<br> Email: " + profiles[i].email + "<br> Address: " + profiles[i].address;
  }
}